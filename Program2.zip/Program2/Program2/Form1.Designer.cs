﻿namespace Program2
{
    partial class Program2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.creditHours = new System.Windows.Forms.Label();
            this.lastName = new System.Windows.Forms.Label();
            this.credHours = new System.Windows.Forms.TextBox();
            this.lastNameChar = new System.Windows.Forms.TextBox();
            this.regTimeLbl = new System.Windows.Forms.Label();
            this.regTimeOut = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // creditHours
            // 
            this.creditHours.AutoSize = true;
            this.creditHours.Location = new System.Drawing.Point(12, 92);
            this.creditHours.Name = "creditHours";
            this.creditHours.Size = new System.Drawing.Size(223, 20);
            this.creditHours.TabIndex = 0;
            this.creditHours.Text = "Enter Number of Credit Hours:";
            // 
            // lastName
            // 
            this.lastName.AutoSize = true;
            this.lastName.Location = new System.Drawing.Point(12, 134);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(232, 20);
            this.lastName.TabIndex = 1;
            this.lastName.Text = "Enter First Letter of Last Name:";
            // 
            // credHours
            // 
            this.credHours.Location = new System.Drawing.Point(308, 89);
            this.credHours.Name = "credHours";
            this.credHours.Size = new System.Drawing.Size(100, 26);
            this.credHours.TabIndex = 2;
            // 
            // lastNameChar
            // 
            this.lastNameChar.Location = new System.Drawing.Point(308, 131);
            this.lastNameChar.Name = "lastNameChar";
            this.lastNameChar.Size = new System.Drawing.Size(100, 26);
            this.lastNameChar.TabIndex = 3;
            // 
            // regTimeLbl
            // 
            this.regTimeLbl.AutoSize = true;
            this.regTimeLbl.Location = new System.Drawing.Point(12, 323);
            this.regTimeLbl.Name = "regTimeLbl";
            this.regTimeLbl.Size = new System.Drawing.Size(227, 20);
            this.regTimeLbl.TabIndex = 4;
            this.regTimeLbl.Text = "Time Available for Registration:";
            // 
            // regTimeOut
            // 
            this.regTimeOut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.regTimeOut.Location = new System.Drawing.Point(308, 322);
            this.regTimeOut.Name = "regTimeOut";
            this.regTimeOut.Size = new System.Drawing.Size(171, 79);
            this.regTimeOut.TabIndex = 5;
            // 
            // calcButton
            // 
            this.calcButton.Location = new System.Drawing.Point(227, 219);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(181, 32);
            this.calcButton.TabIndex = 6;
            this.calcButton.Text = "Find Registration Time";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // Program2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(491, 442);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.regTimeOut);
            this.Controls.Add(this.regTimeLbl);
            this.Controls.Add(this.lastNameChar);
            this.Controls.Add(this.credHours);
            this.Controls.Add(this.lastName);
            this.Controls.Add(this.creditHours);
            this.Name = "Program2";
            this.Text = "Program 2";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label creditHours;
        private System.Windows.Forms.Label lastName;
        private System.Windows.Forms.TextBox credHours;
        private System.Windows.Forms.TextBox lastNameChar;
        private System.Windows.Forms.Label regTimeLbl;
        private System.Windows.Forms.Label regTimeOut;
        private System.Windows.Forms.Button calcButton;
    }
}

