﻿// W9877
// 03-08-18
// CIS 199-01
// Program 2
// This application recieves a students credit hours and last name
// and returns the earliest time when they will be allowed to
// register for classes.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Program2
{
    public partial class Program2 : Form
    {
        public Program2()
        {
            InitializeComponent();
        }

        private void calcButton_Click(object sender, EventArgs e)
        {
            int credHoursVal;
            char lastInitial;
            const string seniorDay = "Wednesday, March 28"; // Date when seniors register
            const string juniorDay = "Thursday, March 29"; // Date when juniors register
            const string sophomoreDay = "Friday, March 30"; // First date when sophomores register
            const string sophomoreDay2 = "Monday, April 2"; // Second date when sophomores register
            const string freshmanDay = "Tuesday, April 3"; // First date when freshman register
            const string freshmanDay2 = "Wednesday, April 4"; // Second date when freshman register
            const string earlyAmTime = "8:30"; // The earliest time slot for registering
            const string midAmTime = "10:00"; // The second earliest time slot for registering
            const string lateAmTime = "11:30"; // The middle time slot for registering
            const string earlyPmTime = "2:00"; // The second latest time slot for registering
            const string latePmTime = "4:00"; // The longest time slot for registering
            string date; // Represents the date on which they will be eligible to register
            string time; // Represents the time at which they will be eliglble to register

            // Recieve User Input

            int.TryParse(credHours.Text, out credHoursVal);
            char.TryParse(lastNameChar.Text, out lastInitial);

            // Calulate Date

            if (credHoursVal >= 90)
                date = seniorDay;
            else
                if (credHoursVal >= 60)
                date = juniorDay;
            else
                if (credHoursVal >= 30 && lastInitial >= 'A' && lastInitial <= 'L')
                date = sophomoreDay;
            else
                if (credHoursVal >= 30 && lastInitial >= 'M' && lastInitial <= 'Z')
                date = sophomoreDay2;
            else
                if (credHoursVal >= 0 && lastInitial >= 'A' && lastInitial <= 'L')
                date = freshmanDay;
            else
                date = freshmanDay2;

            // Calculate Time for Upperclass

            if (credHoursVal >= 60 && (lastInitial <= 'A' && lastInitial >= 'D'))
                time = earlyAmTime;
            else
                if (credHoursVal >= 60 && (lastInitial <= 'E' && lastInitial >= 'I'))
                time = midAmTime;
            else
                if (credHoursVal >= 60 && (lastInitial <= 'J' && lastInitial >= 'O'))
                time = lateAmTime;
            else
                if (credHoursVal >= 60 && (lastInitial <= 'P' && lastInitial >= 'S'))
                time = earlyPmTime;
            else
                time = latePmTime;

            // Calculate time for Underclass

            if (credHoursVal <= 59 && (lastInitial <= 'A' && lastInitial >= 'B' || lastInitial <= 'M' && lastInitial >= 'O'))
                time = earlyAmTime;
            else
                if (credHoursVal <= 59 && (lastInitial <= 'P' && lastInitial >= 'Q' || lastInitial <= 'C' && lastInitial >= 'D'))
                time = midAmTime;
            else
                if (credHoursVal <= 59 && (lastInitial <= 'E' && lastInitial >= 'F' || lastInitial <= 'R' && lastInitial >= 'S'))
                time = lateAmTime;
            else
                if (credHoursVal <= 59 && (lastInitial <= 'G' && lastInitial >= 'I' || lastInitial <= 'T' && lastInitial >= 'V'))
                time = earlyPmTime;
            else
                time = latePmTime;

            // Display results
            regTimeOut.Text = $"{date} {time}";











        }
    }
}
