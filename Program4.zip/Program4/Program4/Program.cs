﻿// W9877
// 04-24-18
// CIS 199-01
// Program 4
// This appplication uses multiple classes and methods to determine various attributes
// about a given package
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace Program4
{
    class Program
    {
        static void Main(string[] args)
        {
            string[]GroundPackage = {  "123", "343", "234", "564", "757" };   
        }

        // Precondition: Package is contained with the array
        // Postcondition: Package details including cost are returned
        public static void DisplayPackages(GroundPackage[])
        {
            string myPackageData; // full string of package details
            double myPackageCost; // amount of calculate cost for the package
            int x;
            for (x = 0; x < GroundPackage.Length; ++x)

              myPackageData = ToString();
              myPackageCost = CalcCost();

            WriteLine($"{myPackageData}");
            WriteLine($"{myPackageCost:C2}");
        }
    }
}

