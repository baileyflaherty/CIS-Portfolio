﻿// W9877
// 04-24-18
// CIS 199-01
// Program 4
// This appplication uses multiple classes and methods to determine various attributes
// about a given package
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;
namespace Program4
{
    public class GroundPackage
    {
        const int maxZip = 99999; // MAX possible zip code
        const int minZip = 00000; // MIN possible zip code
        const int defaultOrginZip = 40202; // default zip if invalid is given
        const int defaultDestZip = 90210; // default zip if invalid is given
        const double defaultMeasurement = 1.0; // default dimension if invalid is given
        const int firstZipDigit = 10000; // number to be used to find first digit in zip code
        const double sizeFactor = .20; // size factor used to calculate cost
        const double distanceFactor = .5; // distance factor used to calculate cost

        public GroundPackage(int orginZip, int destZip, double length, double width, double height, double weight)
        {
            orginZip = OrginZip;
            destZip = DestZip;
            length = Length;
            width = Width;
            height = Height;

            int zoneDistance = (orginZip / firstZipDigit) - (destZip / firstZipDigit);
            zoneDistance = ZoneDistance;
        }
            public int OrginZip { get; set; }
            public int DestZip { get; set; }
            public double Length { get; set; }
            public double Width { get; set; }
            public double Height { get; set; }
            public double Weight { get; set; }
            public int ZoneDistance { get; }

            // Precondition: Length,Width,Height,Weight,SizeFactor,DistanceFactor and ZoneDistance are provided
            // Postcondition: Package cost is returned
            public double CalcCost()
            {
                double cost;
                cost = sizeFactor*(Length*Width*Height)+distanceFactor*((ZoneDistance+1)*Weight);
                return cost;
            }

            // Precondition: Length,Width,Height,Weight,Orgin Zip, and Destination Zip are provided
            // Postcondition: Package details are returned in a string 
            public override string ToString()
                {
                    string data;
                    data = ($"{OrginZip} {DestZip} {Length} {Width} {Height} {Weight}");
                    WriteLine(data, Environment.NewLine);
                    return data;
                }

            
            
            
            

        }
            

        }