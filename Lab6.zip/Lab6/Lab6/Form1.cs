﻿// W9877
// 03-25-18
// CIS 199-01
// Lab 6
// This application recieves a number of words typed by the user
// and returns the appropriate letter grade.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab6
{
    public partial class Lab6 : Form
    {
        public Lab6()
        {
            InitializeComponent();
        }

        private void gradeBtn_Click(object sender, EventArgs e)
        {
   
            int wordsNum; // Number of Words Inputed
            bool valid = false;
            int[] gradeLimits = { 0, 16, 31, 51, 76 }; // Lower limits for Grades
            string[] letterGrades = { "F", "D", "C", "B", "A" }; // Possible Letter Grades
            string letterGrade = "Invalid"; // For invalid number of words input
            int index = gradeLimits.Length - 1; // Begin from highest because lower limits


            // Recieve User Input
            wordsNum = int.Parse(wordsInput.Text);


            // Determine Grade
            while (index >= 0 && !valid)
            {
                if (wordsNum >= gradeLimits[index])
                    valid = true;
                else
                    --index;
            }

            // Display Output
            if (valid)
            {
                letterGrade = letterGrades[index];
                gradeOutput.Text = letterGrade;
            }
            else
                MessageBox.Show(letterGrade);
        }
    }
}
