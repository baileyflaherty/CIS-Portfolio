﻿namespace Lab6
{
    partial class Lab6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.wordsTypedLbl = new System.Windows.Forms.Label();
            this.yourGradeLbl = new System.Windows.Forms.Label();
            this.wordsInput = new System.Windows.Forms.TextBox();
            this.gradeBtn = new System.Windows.Forms.Button();
            this.gradeOutput = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // wordsTypedLbl
            // 
            this.wordsTypedLbl.AutoSize = true;
            this.wordsTypedLbl.Location = new System.Drawing.Point(12, 141);
            this.wordsTypedLbl.Name = "wordsTypedLbl";
            this.wordsTypedLbl.Size = new System.Drawing.Size(227, 20);
            this.wordsTypedLbl.TabIndex = 0;
            this.wordsTypedLbl.Text = "Enter Number of Words Typed:";
            // 
            // yourGradeLbl
            // 
            this.yourGradeLbl.AutoSize = true;
            this.yourGradeLbl.Location = new System.Drawing.Point(143, 286);
            this.yourGradeLbl.Name = "yourGradeLbl";
            this.yourGradeLbl.Size = new System.Drawing.Size(96, 20);
            this.yourGradeLbl.TabIndex = 1;
            this.yourGradeLbl.Text = "Your Grade:";
            // 
            // wordsInput
            // 
            this.wordsInput.Location = new System.Drawing.Point(246, 134);
            this.wordsInput.Name = "wordsInput";
            this.wordsInput.Size = new System.Drawing.Size(100, 26);
            this.wordsInput.TabIndex = 2;
            // 
            // gradeBtn
            // 
            this.gradeBtn.Location = new System.Drawing.Point(246, 204);
            this.gradeBtn.Name = "gradeBtn";
            this.gradeBtn.Size = new System.Drawing.Size(100, 30);
            this.gradeBtn.TabIndex = 3;
            this.gradeBtn.Text = "Grade";
            this.gradeBtn.UseVisualStyleBackColor = true;
            this.gradeBtn.Click += new System.EventHandler(this.gradeBtn_Click);
            // 
            // gradeOutput
            // 
            this.gradeOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.gradeOutput.Location = new System.Drawing.Point(246, 285);
            this.gradeOutput.Name = "gradeOutput";
            this.gradeOutput.Size = new System.Drawing.Size(100, 23);
            this.gradeOutput.TabIndex = 4;
            // 
            // Lab6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 458);
            this.Controls.Add(this.gradeOutput);
            this.Controls.Add(this.gradeBtn);
            this.Controls.Add(this.wordsInput);
            this.Controls.Add(this.yourGradeLbl);
            this.Controls.Add(this.wordsTypedLbl);
            this.Name = "Lab6";
            this.Text = "Lab 6";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label wordsTypedLbl;
        private System.Windows.Forms.Label yourGradeLbl;
        private System.Windows.Forms.TextBox wordsInput;
        private System.Windows.Forms.Button gradeBtn;
        private System.Windows.Forms.Label gradeOutput;
    }
}

