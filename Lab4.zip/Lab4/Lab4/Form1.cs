﻿// W9877
// CIS 199-01
// 02-18-2018
// Lab 4

// This lab recieves both a GPA and test score as input from
// the user and returns whether they will be accepted or
// declined as well as keeping a running total of each
// application that is accepted or declined.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Lab4
{
    public partial class Lab4 : Form
    {

    
        public Lab4()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            float gpaScore; // The GPA entered by the user
            byte testScore; // The test score entered by the user


            // Recieve user input
            float.TryParse(gpaInput.Text, out gpaScore);
            byte.TryParse(testScoreInput.Text, out testScore);

            // Display Output
            if ((gpaScore >= 3.0 && testScore >= 60) || (gpaScore < 3.0 && testScore >= 80))
                outLbl.Text = "Accept";
            else
                outLbl.Text = "Reject";
            

            


        

            
            




       


            



        }
    }
}
