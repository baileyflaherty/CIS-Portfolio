﻿namespace Lab4
{
    partial class Lab4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gpaInput = new System.Windows.Forms.TextBox();
            this.testScoreInput = new System.Windows.Forms.TextBox();
            this.submitButton = new System.Windows.Forms.Button();
            this.gpaLbl = new System.Windows.Forms.Label();
            this.testLbl = new System.Windows.Forms.Label();
            this.statusLbl = new System.Windows.Forms.Label();
            this.outLbl = new System.Windows.Forms.Label();
            this.totalAcceptedOutput = new System.Windows.Forms.Label();
            this.totalRejectedOutput = new System.Windows.Forms.Label();
            this.totalAcceptedLbl = new System.Windows.Forms.Label();
            this.totalRejectedLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // gpaInput
            // 
            this.gpaInput.Location = new System.Drawing.Point(241, 71);
            this.gpaInput.Name = "gpaInput";
            this.gpaInput.Size = new System.Drawing.Size(100, 26);
            this.gpaInput.TabIndex = 0;
            // 
            // testScoreInput
            // 
            this.testScoreInput.Location = new System.Drawing.Point(241, 126);
            this.testScoreInput.Name = "testScoreInput";
            this.testScoreInput.Size = new System.Drawing.Size(100, 26);
            this.testScoreInput.TabIndex = 1;
            // 
            // submitButton
            // 
            this.submitButton.Location = new System.Drawing.Point(241, 184);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(100, 30);
            this.submitButton.TabIndex = 2;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = true;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // gpaLbl
            // 
            this.gpaLbl.AutoSize = true;
            this.gpaLbl.Location = new System.Drawing.Point(122, 74);
            this.gpaLbl.Name = "gpaLbl";
            this.gpaLbl.Size = new System.Drawing.Size(90, 20);
            this.gpaLbl.TabIndex = 3;
            this.gpaLbl.Text = "Enter GPA:";
            // 
            // testLbl
            // 
            this.testLbl.AutoSize = true;
            this.testLbl.Location = new System.Drawing.Point(79, 129);
            this.testLbl.Name = "testLbl";
            this.testLbl.Size = new System.Drawing.Size(133, 20);
            this.testLbl.TabIndex = 4;
            this.testLbl.Text = "Enter Test Score:";
            // 
            // statusLbl
            // 
            this.statusLbl.AutoSize = true;
            this.statusLbl.Location = new System.Drawing.Point(126, 258);
            this.statusLbl.Name = "statusLbl";
            this.statusLbl.Size = new System.Drawing.Size(86, 20);
            this.statusLbl.TabIndex = 5;
            this.statusLbl.Text = "Admission:";
            // 
            // outLbl
            // 
            this.outLbl.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.outLbl.Location = new System.Drawing.Point(241, 257);
            this.outLbl.Name = "outLbl";
            this.outLbl.Size = new System.Drawing.Size(100, 23);
            this.outLbl.TabIndex = 6;
            // 
            // totalAcceptedOutput
            // 
            this.totalAcceptedOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalAcceptedOutput.Location = new System.Drawing.Point(241, 303);
            this.totalAcceptedOutput.Name = "totalAcceptedOutput";
            this.totalAcceptedOutput.Size = new System.Drawing.Size(100, 23);
            this.totalAcceptedOutput.TabIndex = 7;
            // 
            // totalRejectedOutput
            // 
            this.totalRejectedOutput.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.totalRejectedOutput.Location = new System.Drawing.Point(241, 350);
            this.totalRejectedOutput.Name = "totalRejectedOutput";
            this.totalRejectedOutput.Size = new System.Drawing.Size(100, 23);
            this.totalRejectedOutput.TabIndex = 8;
            // 
            // totalAcceptedLbl
            // 
            this.totalAcceptedLbl.AutoSize = true;
            this.totalAcceptedLbl.Location = new System.Drawing.Point(92, 304);
            this.totalAcceptedLbl.Name = "totalAcceptedLbl";
            this.totalAcceptedLbl.Size = new System.Drawing.Size(120, 20);
            this.totalAcceptedLbl.TabIndex = 9;
            this.totalAcceptedLbl.Text = "Total Accepted:";
            // 
            // totalRejectedLbl
            // 
            this.totalRejectedLbl.AutoSize = true;
            this.totalRejectedLbl.Location = new System.Drawing.Point(96, 351);
            this.totalRejectedLbl.Name = "totalRejectedLbl";
            this.totalRejectedLbl.Size = new System.Drawing.Size(116, 20);
            this.totalRejectedLbl.TabIndex = 10;
            this.totalRejectedLbl.Text = "Total Rejected:";
            // 
            // Lab4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 423);
            this.Controls.Add(this.totalRejectedLbl);
            this.Controls.Add(this.totalAcceptedLbl);
            this.Controls.Add(this.totalRejectedOutput);
            this.Controls.Add(this.totalAcceptedOutput);
            this.Controls.Add(this.outLbl);
            this.Controls.Add(this.statusLbl);
            this.Controls.Add(this.testLbl);
            this.Controls.Add(this.gpaLbl);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.testScoreInput);
            this.Controls.Add(this.gpaInput);
            this.Name = "Lab4";
            this.Text = "Lab4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox gpaInput;
        private System.Windows.Forms.TextBox testScoreInput;
        private System.Windows.Forms.Button submitButton;
        private System.Windows.Forms.Label gpaLbl;
        private System.Windows.Forms.Label testLbl;
        private System.Windows.Forms.Label statusLbl;
        private System.Windows.Forms.Label outLbl;
        private System.Windows.Forms.Label totalAcceptedOutput;
        private System.Windows.Forms.Label totalRejectedOutput;
        private System.Windows.Forms.Label totalAcceptedLbl;
        private System.Windows.Forms.Label totalRejectedLbl;
    }
}

